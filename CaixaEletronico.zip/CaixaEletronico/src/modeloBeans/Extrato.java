/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloBeans;

/**
 *
 * @author bbrog
 */
public class Extrato {

    private String data;
    private String transacao;
    private Double valor;
    private String saldo;

    public String getSaldo() {
        return saldo;
    }

    public void setSaldo(String saldo) {
        this.saldo = saldo;
    }

    public int getNumConta() {
        return NumConta;
    }

    public void setNumConta(int NumConta) {
        this.NumConta = NumConta;
    }
    int NumConta;
    

    public int getIdConta() {
        return NumConta;
    }

    public void setIdConta(int NumConta) {
        this.NumConta = NumConta;
    }

    public String getData() {
        
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getTransacao() {
        return transacao;
    }

    public void setTransacao(String transacao) {
        this.transacao = transacao;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

}
