package visao;

import modeloBeans.Cliente;
import modeloDAO.DAOCliente;

/**
 *
 * @author bbrog
 */
public class CaixaEletronico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //para cadastrar novos clientes
        
        Cliente mod = new Cliente();
        DAOCliente control = new DAOCliente();
        
        mod.setNome("cliente1");
        
        control.Salvar(mod);
        
        mod.setNome("cliente2");
        
        control.Salvar(mod);
        
        

    }

}
