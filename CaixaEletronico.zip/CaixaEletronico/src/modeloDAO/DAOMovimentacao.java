/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloDAO;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import conexao.Conexao;
import modeloBeans.Extrato;

/**
 *
 * @author bbrog
 */
public class DAOMovimentacao {

    Conexao conex = new Conexao();
    Extrato mod = new Extrato();
    

    public void sacar(Extrato mod) {

        conex.conecta();

        try {

            PreparedStatement pst = conex.conexao.prepareStatement(
                    "insert into bd_caixa_eletronico.extrato (Valor, Data, Transacao, NumConta) values (?, ?, ?, ?)");

            pst.setDouble(1, mod.getValor());
            pst.setString(2, mod.getData());
            pst.setString(3, mod.getTransacao());
            pst.setInt(4, mod.getIdConta());

            pst.execute();

            JOptionPane.showMessageDialog(null, "Saque efetuado com sucesso.");

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(null, "Erro ao salvar o valor./nErro: " + ex);
        }

        conex.desconecta();

    }
    
    public void depositar(Extrato mod) {

        conex.conecta();

        try {

            PreparedStatement pst = conex.conexao.prepareStatement(
               "insert into bd_caixa_eletronico.extrato (Valor, Data, Transacao, NumConta) values (?, ?, ?, ?)");

            pst.setDouble(1, mod.getValor());
            pst.setString(2, mod.getData());
            pst.setString(3, mod.getTransacao());
            pst.setInt(4, mod.getIdConta());

            pst.execute();

            JOptionPane.showMessageDialog(null, "Depósito efetuado com sucesso.");

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(null, "Erro ao salvar o valor./nErro: " + ex);
        }

        conex.desconecta();

    }

    public Extrato emitirSaldo(Extrato mod) {

        conex.conecta();
        conex.executeSQL
        
        ("SELECT (SELECT SUM(valor) FROM extrato where Transacao = 'Deposito') "
            + "- (SELECT SUM(valor) FROM extrato where Transacao = 'Saque')");

        try {
            
            conex.resultset.first();
            mod.setSaldo(conex.resultset.getString(1));
            
            //JOptionPane.showMessageDialog(null, "Saldo recebido.");
                       
        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(null, "Erro ao apresentar o saldo./nErro: " + ex);
        }

        conex.desconecta();
        
        return mod;

    }
    
}
