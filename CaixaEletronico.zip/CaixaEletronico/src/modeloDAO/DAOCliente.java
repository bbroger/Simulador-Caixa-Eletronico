/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloDAO;

import conexao.Conexao;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modeloBeans.Cliente;

/**
 *
 * @author bbrog
 */
public class DAOCliente {

    Conexao conex = new Conexao();
    Cliente mod = new Cliente();

    public void Salvar(Cliente mod) {

        conex.conecta();
        
        try {
            
            PreparedStatement pst = conex.conexao.prepareStatement(
                    
                    "insert into bd_caixa_eletronico.cliente (nome) values (?)");

            pst.setString(1, mod.getNome());

            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Cliente salvo com sucesso.");

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(null, "Erro ao salvar cliente./nErro: " + ex);
        }

        conex.desconecta();

    }

}
